<?php

namespace BankSystem;

class BankTransfer implements TransactionInterface
{
    
}