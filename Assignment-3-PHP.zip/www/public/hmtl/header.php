<head>
    <script src="public/javascript/main.js"></script>
</head>